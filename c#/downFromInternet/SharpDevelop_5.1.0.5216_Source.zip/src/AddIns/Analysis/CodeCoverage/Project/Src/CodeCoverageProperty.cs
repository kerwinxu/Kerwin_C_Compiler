﻿// Copyright (c) 2014 AlphaSierraPapa for the SharpDevelop Team
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of this
// software and associated documentation files (the "Software"), to deal in the Software
// without restriction, including without limitation the rights to use, copy, modify, merge,
// publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
// to whom the Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all copies or
// substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
// INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
// FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
// DEALINGS IN THE SOFTWARE.

using System;
using System.Collections.Generic;

namespace ICSharpCode.CodeCoverage
{
	public class CodeCoverageProperty
	{
		string name = String.Empty;
		CodeCoverageMethod getter;
		CodeCoverageMethod setter;
		
		public CodeCoverageProperty()
		{
		}
		
		public CodeCoverageProperty(CodeCoverageMethod method)
		{
			AddMethod(method);
		}
		
		public List<CodeCoverageMethod> GetMethods()
		{
			List<CodeCoverageMethod> methods = new List<CodeCoverageMethod>();
			if (getter != null) {
				methods.Add(getter);
			}
			if (setter != null) {
				methods.Add(setter);
			}
			return methods;
		}
		
		/// <summary>
		/// Gets the property name.
		/// </summary>
		public string Name {
			get { return name; }
		}
		
		public CodeCoverageMethod Getter {
			get { return getter; }
		}
		
		public CodeCoverageMethod Setter {
			get { return setter; }
		}
		
		/// <summary>
		/// Adds a getter or setter to the property.
		/// </summary>
		public void AddMethod(CodeCoverageMethod method)
		{
			name = GetPropertyName(method);
			if (method.IsGetter) {
				getter = method;
			} else {
				setter = method;
			}
		}
		
		/// <summary>
		/// Strips the get_ or set_ part from a method name and returns the property name.
		/// </summary>
		public static string GetPropertyName(CodeCoverageMethod method)
		{
			if (method.IsProperty) {
				return method.Name.Substring(4);
			}
			return String.Empty;
		}
	}
}
