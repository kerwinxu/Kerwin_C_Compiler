Inserts PInvoke signatures into VB.Net or C# source code.
---------------------------------------------------------

Features
--------

Search PInvoke signatures held at http://www.pinvoke.net
Insert C# or VB.Net signatures into source code.

Menu option
-----------

Tools->Insert PInvoke Signatures...

Right click context menu
------------------------

Right click in a ".vb" or ".cs" file and select "Insert PInvoke Signatures...".
  

Limitations
-----------

No support for connecting to http://www.pinvoke.net through a proxy.