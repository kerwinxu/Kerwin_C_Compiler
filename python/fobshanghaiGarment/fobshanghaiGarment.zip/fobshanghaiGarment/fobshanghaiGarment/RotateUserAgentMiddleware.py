#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Last Change:  2016-10-24 17:14:42
# Author:  kerwin.cn@gmail.com
# Created Time:2015-10-25 16:34:43
# Last modified: 2016-04-29 22:04:44
# File Name: RotateUserAgentMiddleware.py


import random
from scrapy.contrib.downloadermiddleware.useragent import UserAgentMiddleware
from fobshanghaiGarment import logger
import base64
from settings import PROXIES
from settings import user_agent_list


# 该代码片段来自于: http://www.sharejs.com/codes/python/8310
class RotateUserAgentMiddleware(UserAgentMiddleware):
    def __init__(self, user_agent=''):
        self.user_agent = user_agent

    def process_request(self, request, spider):
        # 这句话用于随机选择user-agent
        ua = random.choice(user_agent_list)
        logger.info('User-Agent:' + ua)
        if ua:
            request.headers.setdefault('User-Agent', ua)


# 如下代码段来自于 http://www.tuicool.com/articles/VRfQR3U
class ProxyMiddleware(object):
    def process_request(self, request, spider):
        proxy = random.choice(PROXIES)
        if proxy['user_pass'] is not None:
            request.meta['proxy'] = "http://%s" % proxy['ip_port']
            encoded_user_pass = base64.encodestring(proxy['user_pass'])
            request.headers['Proxy-Authorization'] = 'Basic ' + encoded_user_pass
            logger.info("**************ProxyMiddleware have pass************" + proxy['ip_port'])
        else:
            logger.info("**************ProxyMiddleware no pass************" + proxy['ip_port'])
            request.meta['proxy'] = "http://%s" % proxy['ip_port']
