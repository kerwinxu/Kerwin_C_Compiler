import logging


# Last Change:  2016-10-31 12:17:46
logger = logging.getLogger('log1')
